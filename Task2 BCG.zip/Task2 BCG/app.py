from flask import Flask, request, jsonify
import pandas as pd

app = Flask(__name__)

# Load financial data
file_path = "SEC.csv"
df = pd.read_csv(file_path)

# Convert 'Fiscal Year Ended' to an integer (extract only year)
df["Fiscal Year Ended"] = df["Fiscal Year Ended"].astype(str).str.extract(r'(\d{4})').astype(int)

# Convert numeric columns from string to float
numeric_columns = [
    "Total Revenue (USD millions)", 
    "Net Income (USD millions)", 
    "Total Assets (USD millions)", 
    "Total Liabilities (USD millions)", 
    "Cash Flow from Operating Activities (USD millions)"
]

for col in numeric_columns:
    df[col] = df[col].astype(str).str.replace(",", "").astype(float)

# ✅ Calculate Revenue Growth & Net Income Growth before using them
df['Revenue Growth (%)'] = df.groupby('Company')['Total Revenue (USD millions)'].pct_change() * 100
df['Net Income Growth (%)'] = df.groupby('Company')['Net Income (USD millions)'].pct_change() * 100

# Debugging: Print updated columns
print("Columns in DataFrame after calculations:", df.columns.tolist())


# Define chatbot function
def simple_chatbot(user_query, company_name=None):
    user_query = user_query.lower().strip()

    if user_query == "what is the total revenue?":
        total_revenue = df["Total Revenue (USD millions)"].sum()
        return f"The total revenue across all companies is {float(total_revenue):,.2f} million USD."

    elif user_query == "how has net income changed over the last year?":
        last_year = df["Fiscal Year Ended"].max()
        previous_year = last_year - 1  
        net_income_last = df[df["Fiscal Year Ended"] == last_year]["Net Income (USD millions)"].sum()
        net_income_prev = df[df["Fiscal Year Ended"] == previous_year]["Net Income (USD millions)"].sum()
        change = net_income_last - net_income_prev
        return f"Net income has {'increased' if change > 0 else 'decreased'} by {abs(float(change)):,.2f} million USD from {previous_year} to {last_year}."

    elif user_query == "which company had the highest revenue in the last year?":
        last_year = df["Fiscal Year Ended"].max()
        top_company = df[df["Fiscal Year Ended"] == last_year].sort_values("Total Revenue (USD millions)", ascending=False).iloc[0]
        return f"The company with the highest revenue in {last_year} is {top_company['Company']} with {float(top_company['Total Revenue (USD millions)']):,.2f} million USD."

    elif user_query == "what is the net income for a specific company?" and company_name:
        company_data = df[df["Company"].str.lower() == company_name.lower()]
        if not company_data.empty:
            latest_entry = company_data.iloc[-1]
            return f"{company_name}'s net income for {latest_entry['Fiscal Year Ended']} is {float(latest_entry['Net Income (USD millions)']):,.2f} million USD."
        else:
            return f"Sorry, I couldn't find data for {company_name}."

    elif user_query == "what is the revenue growth of a company?" and company_name:
        company_data = df[df["Company"].str.lower() == company_name.lower()]
        if not company_data.empty:
            latest_entry = company_data.iloc[-1]
            return f"{company_name}'s revenue growth for {latest_entry['Fiscal Year Ended']} is {float(latest_entry['Revenue Growth (%)']):.2f}%."
        else:
            return f"Sorry, I couldn't find revenue growth data for {company_name}."

    else:
        return "Sorry, I can only provide information on predefined queries."


# Flask API route
@app.route('/chatbot', methods=['GET'])
def chatbot():
    query = request.args.get('query', '').lower()
    company = request.args.get('company', '')

    response = simple_chatbot(query, company)
    return jsonify({"response": response})


if __name__ == '__main__':
    app.run(debug=True)
