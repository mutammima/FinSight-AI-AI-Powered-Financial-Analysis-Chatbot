import pandas as pd
from app import simple_chatbot  # Import chatbot function

# Define test queries
test_queries = [
    ("What is the total revenue?", None),
    ("How has net income changed over the last year?", None),
    ("Which company had the highest revenue in the last year?", None),
    ("What is the net income for a specific company?", "Apple"),
    ("What is the net income for a specific company?", "Tesla"),
    ("What is the net income for a specific company?", "Microsoft"),
    ("What is the revenue growth of a company?", "Apple"),
    ("What is the revenue growth of a company?", "Tesla"),
]

# Store results
test_results = []

for query, company in test_queries:
    response = simple_chatbot(query, company)
    test_results.append({"Query": query, "Company": company if company else "N/A", "Response": response})

# Convert to DataFrame
df_results = pd.DataFrame(test_results)

# Save to CSV
df_results.to_csv("chatbot_test_results.csv", index=False)

# Save to Text File (optional)
with open("chatbot_test_results.txt", "w") as f:
    for result in test_results:
        f.write(f"Query: {result['Query']}\n")
        f.write(f"Company: {result['Company']}\n")
        f.write(f"Response: {result['Response']}\n")
        f.write("-" * 50 + "\n")

print("Test results saved successfully.")
